
import express from 'express';
import cookieParser from 'cookie-parser';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import Database from 'better-sqlite3';
import path from 'path';
import fs from 'fs';
import cors from 'cors';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ADMIN_USER = 'sajid7254';
const ADMIN_PASS = 'Golu@777';
const JWT_SECRET = process.env.JWT_SECRET || 'dev-secret-change-me';
const PORT = process.env.PORT || 3000;

const dbPath = path.join(__dirname, 'data.db');
const db = new Database(dbPath);

// Init tables
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL,
  active INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS downloads (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  ts INTEGER NOT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
`);

const app = express();
app.use(cors({ origin: true, credentials: true }));
app.use(express.json());
app.use(cookieParser());

// Helpers
const now = () => Date.now();
const signToken = (payload) => jwt.sign(payload, JWT_SECRET, { expiresIn: '12h' });

function authOptional(req, res, next){
  const token = req.cookies.auth;
  if(!token) return next();
  try{
    req.user = jwt.verify(token, JWT_SECRET);
  } catch(e){ /* ignore */ }
  next();
}

function authRequired(role){
  return (req, res, next) => {
    const token = req.cookies.auth;
    if(!token) return res.status(401).json({error:'Not authenticated'});
    try{
      const payload = jwt.verify(token, JWT_SECRET);
      if(role && payload.role !== role) return res.status(403).json({error:'Forbidden'});
      req.user = payload;
      next();
    }catch(e){
      return res.status(401).json({error:'Invalid token'});
    }
  }
}

// API: login/logout/me
app.post('/api/login', async (req,res) => {
  const { username, password } = req.body || {};
  if(!username || !password) return res.status(400).json({error:'Username & password required'});

  // Admin
  if(username === ADMIN_USER && password === ADMIN_PASS){
    const token = signToken({ role:'admin', username: ADMIN_USER });
    res.cookie('auth', token, { httpOnly: true, sameSite: 'lax', maxAge: 12*60*60*1000 });
    return res.json({ ok:true, role:'admin' });
  }

  // User
  const row = db.prepare('SELECT * FROM users WHERE username = ?').get(username);
  if(!row) return res.status(400).json({error:'Invalid credentials'});
  const ok = await bcrypt.compare(password, row.password_hash);
  if(!ok) return res.status(400).json({error:'Invalid credentials'});
  if(!row.active) return res.status(403).json({error:'User disabled'});
  if(row.expires_at < now()) return res.status(403).json({error:'Access expired'});
  const token = signToken({ role:'user', username, user_id: row.id, expAt: row.expires_at });
  res.cookie('auth', token, { httpOnly: true, sameSite: 'lax', maxAge: 12*60*60*1000 });
  return res.json({ ok:true, role:'user' });
});

app.post('/api/logout', (req,res) => {
  res.clearCookie('auth');
  res.json({ok:true});
});

app.get('/api/me', authOptional, (req,res) => {
  if(!req.user) return res.json({ ok:false });
  return res.json({ ok:true, user: req.user });
});

// Admin routes
app.get('/api/users', authRequired('admin'), (req,res) => {
  const rows = db.prepare('SELECT id, username, created_at, expires_at, active FROM users ORDER BY username ASC').all();
  const nowTs = now();
  const data = rows.map(r => ({
    ...r,
    status: r.expires_at < nowTs ? 'expired' : (r.active ? 'active' : 'disabled'),
    daysRemaining: Math.max(0, Math.ceil((r.expires_at - nowTs) / (1000*60*60*24))),
    downloads: db.prepare('SELECT COUNT(*) AS c FROM downloads WHERE user_id = ?').get(r.id).c
  }));
  res.json({ users: data });
});

app.post('/api/users', authRequired('admin'), async (req,res) => {
  const { username, password, days } = req.body || {};
  if(!username || !password || !days || days < 1) return res.status(400).json({error:'username, password, days>=1 required'});
  const expiresAt = now() + days*24*60*60*1000;
  const hash = await bcrypt.hash(password, 10);
  try {
    db.prepare('INSERT INTO users (username, password_hash, created_at, expires_at, active) VALUES (?,?,?,?,1)')
      .run(username, hash, now(), expiresAt);
  } catch(e){
    // update if exists
    if(String(e).includes('UNIQUE')){
      db.prepare('UPDATE users SET password_hash=?, expires_at=? WHERE username=?').run(hash, expiresAt, username);
    } else {
      throw e;
    }
  }
  res.json({ ok:true });
});

app.patch('/api/users/:id', authRequired('admin'), async (req,res) => {
  const id = Number(req.params.id);
  const { password, addDays, setDays, active } = req.body || {};
  const row = db.prepare('SELECT * FROM users WHERE id=?').get(id);
  if(!row) return res.status(404).json({error:'Not found'});
  let expires = row.expires_at;
  if(typeof addDays === 'number'){
    expires = Math.max(expires, now()) + addDays*24*60*60*1000;
  }
  if(typeof setDays === 'number'){
    expires = now() + setDays*24*60*60*1000;
  }
  let hash = row.password_hash;
  if(password){
    hash = await bcrypt.hash(password, 10);
  }
  const act = (active===0 || active===1) ? active : row.active;
  db.prepare('UPDATE users SET password_hash=?, expires_at=?, active=? WHERE id=?').run(hash, expires, act, id);
  res.json({ ok:true });
});

app.delete('/api/users/:id', authRequired('admin'), (req,res) => {
  const id = Number(req.params.id);
  db.prepare('DELETE FROM users WHERE id=?').run(id);
  res.json({ ok:true });
});

app.get('/api/stats', authRequired('admin'), (req,res) => {
  const all = db.prepare('SELECT id, expires_at, active FROM users').all();
  const nowTs = now();
  const total = all.length;
  const active = all.filter(u => u.active && u.expires_at >= nowTs).length;
  const expired = all.filter(u => u.expires_at < nowTs).length;
  res.json({ total, active, expired });
});

app.get('/api/activity', authRequired('admin'), (req,res) => {
  const rows = db.prepare(`
    SELECT d.id, d.ts, u.username
    FROM downloads d
    JOIN users u ON u.id = d.user_id
    ORDER BY d.ts DESC
    LIMIT 100
  `).all();
  res.json({ activity: rows });
});

// User routes
app.post('/api/downloads/log', authRequired('user'), (req,res) => {
  const uid = req.user.user_id;
  db.prepare('INSERT INTO downloads (user_id, ts) VALUES (?,?)').run(uid, now());
  res.json({ ok:true });
});

app.get('/api/downloads/count', authRequired('user'), (req,res) => {
  const uid = req.user.user_id;
  const c = db.prepare('SELECT COUNT(*) AS c FROM downloads WHERE user_id = ?').get(uid).c;
  res.json({ count: c });
});

// Serve static
app.use('/public', express.static(path.join(__dirname, 'public')));

// Protected app route for user role
app.get('/app', authRequired('user'), (req,res) => {
  const appPath = path.join(__dirname, 'protected', 'app.html');
  res.sendFile(appPath);
});

// Admin page
app.get('/admin', (req,res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin.html'));
});

// Login page
app.get('/', (req,res) => {
  res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

app.listen(PORT, () => {
  console.log('Server running on http://localhost:'+PORT);
});
