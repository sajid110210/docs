
// Simple helper to increment download count for the current user session.
// Call window.logDownload() right after a successful file download in your app.
window.logDownload = async function(){
  try{
    await fetch('/api/downloads/log', { method: 'POST', credentials: 'include' });
  }catch(e){}
}
// Example: you can also query current count:
window.getDownloadCount = async function(){
  try{
    const r = await fetch('/api/downloads/count', { credentials: 'include' });
    if(!r.ok) return 0; const j = await r.json(); return j.count || 0;
  }catch(e){ return 0; }
}
