
# ID Login System (Node + SQLite + Tailwind)

- Admin: `sajid7254` / `Golu@777`
- Tracks per-user download counts
- Users have expiry in days; admin manages users

## Run locally
```bash
npm install
npm start
# open http://localhost:3000
```

## Files
- `server.js` - Express API + auth (JWT cookie), SQLite DB.
- `protected/app.html` - your original app, served to logged-in users at `/app`.
- `public/login.html` - login screen.
- `public/admin.html` - admin dashboard UI.
- `public/helper.js` - helper with `logDownload()` and `getDownloadCount()`.

## Hooking download tracking in your app
In your app's download code (after the file is generated/saved), call:
```html
<script src="/public/helper.js"></script>
<script>
// after download succeeds:
window.logDownload();
</script>
```

## Deploy hints
- This is a single Node server with SQLite (`data.db` file). Deploy on a host with persistent disk (e.g., Render, Railway, Fly.io). Set `JWT_SECRET` env var.
